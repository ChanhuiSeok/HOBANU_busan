package com.example.myapplication;

public class ItemData
{
    public String strTitle;
    public String strDate;
}